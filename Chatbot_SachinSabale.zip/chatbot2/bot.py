from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

chatbot = ChatBot("Chatpot")

trainer = ListTrainer(chatbot)

trainer.train([

    "Hi", "hello",
    "Welcome, my dear friend! 🤗",

    "What is the address of Ai Technologies Pvt.ltd",
    "Address: 3-5-V/11/2, Plot No -890, Vivekananda Nagar, Kukatpally, Hyderabad, Telangana 500072S",

    "What are the core services offered by Switch To AI Technologies?",
    "Switch To AI Technologies provides a range of core services, including reliable and efficient IT services, software development, infrastructural support, web development, and automated chatbot solutions.",

    "Who created you?",
    "I was created by a team of developers of AI Technologies HYDRABAD using the ChatterBot library.",

    "What languages do you understand?",
    "I primarily understand and communicate in English.",

    "ok",
    "Ask me More...",

    "Who created you?",
    "I was created by a team of developers of AI Technologies HYDRABAD using the ChatterBot library.",
])

exit_conditions = (":q", "quit", "exit")

while True:
        query = input(" >> ")
        if query in exit_conditions:
            break
        else:
            print(f"🪴 {chatbot.get_response(query)}")
