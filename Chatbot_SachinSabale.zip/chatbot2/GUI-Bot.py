import tkinter as tk
from tkinter import Scrollbar, Text, Entry, Button, Tk
from chatterbot import ChatBot
from tkinter import PhotoImage
from chatterbot import ChatBot

import tkinter as tk
from tkinter import Scrollbar, Text, Entry, Button
from chatterbot import ChatBot

def send_message():
    user_input = user_entry.get()
    chat_history.config(state='normal')
    chat_history.insert('end', f"You: {user_input}\n")
    chat_history.config(state='disabled')
    user_entry.delete(0, 'end')

    # Schedule the chatbot response after a delay of 500 milliseconds (0.5 seconds)
    root.after(500, lambda: process_chatbot_response(user_input))

def process_chatbot_response(user_input):
    chat_response = chatbot.get_response(user_input)
    chat_history.config(state='normal')
    chat_history.insert('end', f"Bot: {chat_response}\n\n")
    chat_history.config(state='disabled')
    chat_history.yview('end')

chatbot = ChatBot("Chatpot")

root = tk.Tk()
root.title("BotMan - AI Technologies Chatbot")

window_width = 400
window_height = 500
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_position = (screen_width - window_width) // 2
y_position = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

# Widget Colors
entry_background_color = "#FFFFFF"
button_background_color = "#4CAF50"

scrollbar = Scrollbar(root)
chat_history = Text(root, state='disabled', wrap='word', yscrollcommand=scrollbar.set, bg=entry_background_color)
scrollbar.config(command=chat_history.yview)

user_entry = Entry(root, width=25, font=('Arial', 14), bg=entry_background_color)
user_entry.bind('<Return>', lambda event=None: send_message())

send_button = Button(root, text="Send", command=send_message, font=('Arial', 14), bg=button_background_color, fg="white")

scrollbar.pack(side='right', fill='y')
chat_history.pack(expand=True, fill='both', padx=10, pady=10)
user_entry.pack(side='left', expand=True, fill='x', padx=10, pady=10)
send_button.pack(side='right', pady=10)

root.mainloop()
