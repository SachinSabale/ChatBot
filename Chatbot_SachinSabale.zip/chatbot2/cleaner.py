import re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

def clean_corpus(file_path):
    # Load the corpus from the file
    with open(file_path, 'r', encoding='utf-8') as file:
        corpus = file.readlines()

    # Clean and preprocess the corpus
    cleaned_corpus = [preprocess_text(sentence) for sentence in corpus]

    return cleaned_corpus

def preprocess_text(text):
    # Remove special characters and digits
    text = re.sub(r'[^a-zA-Z\s]', '', text)

    text = text.lower()
    tokens = word_tokenize(text)

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]

    # Join the tokens back into a sentence
    cleaned_text = ' '.join(tokens)

    return cleaned_text
